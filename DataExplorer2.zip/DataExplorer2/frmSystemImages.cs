﻿using System;
using System.Windows.Forms;

namespace DataExplorer2
{
    public partial class FrmSystemImages : Form
    {
        public FrmSystemImages()
        {
            InitializeComponent();
        }

        private void FrmSystemImages_Load(object sender, EventArgs e)
        {
        }
    }
}
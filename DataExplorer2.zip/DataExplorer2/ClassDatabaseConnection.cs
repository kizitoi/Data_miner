﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataExplorer2
{
   

 public static  class ClassDatabaseConnection
    {

        // CONNECTION TO MSSQL DATABASE
        public static string cnn1 = "";
        public static string serverName = " ";
        public static string dataBaseName = " ";
        public static string dbUserName = "sa";
        public static string dbPassword = "  ";
        public static string dbTable = " ";

   
    }
}
